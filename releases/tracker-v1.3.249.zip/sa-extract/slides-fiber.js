// Primus SA slides — Strategy 4: MAIN-world React fiber walk + click interception.
//
// Faithful port of slides_content.js's strategy 4. Runs in MAIN world (separate
// chrome.scripting.executeScript({world: 'MAIN'}) call) because it needs access
// to the page's React fiber tree — the "View as PDF" button has no DOM-level
// href; the URL is only in React's `memoizedProps` / `pendingProps`.
//
// Returns { ok: true, slidesUrl } or { ok: false, error: 'no-slides-url' }.
(async () => {
  const PDF_RE = /https?:\/\/[^\s"'<>\\]+\.(pdf|pptx?)[^\s"'<>\\]*/i;

  function findButton() {
    return [...document.querySelectorAll('button, [role="button"], a')]
      .find((el) => /view\s+as\s+pdf|download\s+pdf|download\s+slides|view\s+pdf/i.test(el.textContent || ''));
  }

  function walkFiber(button) {
    const fiberKey = Object.keys(button).find((k) => k.startsWith('__reactFiber') || k.startsWith('__reactInternalInstance'));
    if (!fiberKey) return null;
    let fiber = button[fiberKey];
    const seen = new WeakSet();
    let depth = 0;
    while (fiber && depth < 80) {
      const slots = [
        fiber.memoizedProps,
        fiber.pendingProps,
        fiber.stateNode && fiber.stateNode.props,
        fiber.stateNode && fiber.stateNode.state,
      ];
      for (const slot of slots) {
        if (!slot || typeof slot !== 'object' || seen.has(slot)) continue;
        const stack = [slot];
        let inner = 0;
        while (stack.length && inner < 5000) {
          const obj = stack.pop(); inner++;
          if (!obj || typeof obj !== 'object' || seen.has(obj)) continue;
          seen.add(obj);
          for (const v of Object.values(obj)) {
            if (typeof v === 'string') {
              const m = v.match(PDF_RE);
              if (m) return m[0];
            } else if (v && typeof v === 'object') {
              stack.push(v);
            }
          }
        }
      }
      fiber = fiber.return;
      depth++;
    }
    return null;
  }

  async function viaClick(button) {
    let captured = null;
    const origOpen = window.open;
    const origAClick = HTMLAnchorElement.prototype.click;
    window.open = function (url) {
      if (url) captured = String(url);
      return null;
    };
    HTMLAnchorElement.prototype.click = function () {
      if (this.href && PDF_RE.test(this.href)) { captured = this.href; return; }
      origAClick.call(this);
    };
    try {
      button.click();
      await new Promise((r) => setTimeout(r, 600));
    } catch { /* ignore */ }
    window.open = origOpen;
    HTMLAnchorElement.prototype.click = origAClick;
    return captured;
  }

  const button = findButton();
  if (!button) return { ok: false, error: 'no-slides-url', diagnostics: ['fiber: no view-as-pdf button'] };

  let url = walkFiber(button);
  if (!url) url = await viaClick(button);
  return url
    ? { ok: true, slidesUrl: url, diagnostics: ['fiber: found via ' + (walkFiber(button) ? 'walk' : 'click')] }
    : { ok: false, error: 'no-slides-url', diagnostics: ['fiber: button found but no URL extracted'] };
})();
