// Primus SA transcript extraction — runs in the SA article tab AFTER the
// Readability and turndown library files have been injected (chrome.scripting
// loads them in order before this one). Ported faithfully from the standalone
// Alpha Transcript Downloader's content.js so the resulting markdown is
// byte-equivalent and SA's anti-bot signals are honored.
//
// Returns a plain object that chrome.scripting.executeScript serializes back to
// the Primus extension page. The caller wraps the body in YAML frontmatter.
//
// v1.3.19: the result now also carries `contentHtml` (the pre-turndown
// Readability HTML — lets the S3 gate distinguish media-only stub pages from
// truncated captures) and `sessionHint` (a cheap login-state heuristic that
// annotates rejection logs: looks-logged-in / looks-logged-out / unknown).

(() => {
  function isBotBlockPage() {
    const text = (document.body && (document.body.innerText || document.body.textContent) || '').toLowerCase();
    const hasRefId  = /reference id:\s*[a-f0-9-]+/i.test(text);
    const hasBlocky = text.includes('disable your ad-blocker')
                  || text.includes('javascript and cookies')
                  || text.includes('please enable javascript');
    if (hasRefId && hasBlocky) return true;
    if (hasRefId && text.length < 800) return true;
    const t = (document.title || '').toLowerCase();
    if (t.includes('access denied') || t.includes('attention required') || t === 'just a moment...') return true;
    // v1.3.16 (S2): DataDome / Geetest challenge vocabulary. Trusted only on
    // SHORT pages — a real challenge page is tiny, while these words can
    // appear in legitimate long transcripts (e.g. a tech call mentioning
    // "captcha"). Mirrors saArticle.isBotBlockBody.
    if (text.length < 5000 && (
      text.includes('captcha')
      || text.includes('verify you are human')
      || text.includes('press & hold')
      || text.includes('press and hold')
      || text.includes('geetest')
    )) return true;
    // Geetest / DataDome render the actual challenge inside an iframe while
    // the host page stays nearly text-free (the Reference-Id checks above
    // miss that shape).
    if (text.length < 5000) {
      const frames = document.querySelectorAll('iframe[src]');
      for (let i = 0; i < frames.length; i++) {
        const src = (frames[i].getAttribute('src') || '').toLowerCase();
        if (src.includes('geetest') || src.includes('captcha')) return true;
      }
    }
    return false;
  }

  // v1.3.19: cheap login-state heuristic for rejection diagnostics. Word-
  // boundary phrases from page furniture + an avatar-node probe — heuristic
  // only (annotates logs; never a gate input). Checked AFTER Readability ran
  // on the clone, so the live document is intact.
  function sessionHint() {
    const text = ((document.body && (document.body.innerText || document.body.textContent)) || '').toLowerCase();
    // Logged-in chrome: an avatar node or explicit sign-out affordance.
    if (document.querySelector('[class*="avatar"], [data-test-id*="avatar"], [data-testid*="avatar"]')) {
      return 'looks-logged-in';
    }
    if (/\bsign out\b/.test(text) || /\blog out\b/.test(text)) return 'looks-logged-in';
    // Logged-out chrome: sign-in / create-account CTAs.
    if (/\bsign in\b/.test(text) || /\blog in\b/.test(text) || /\bcreate account\b/.test(text)) {
      return 'looks-logged-out';
    }
    return 'unknown';
  }

  function isSoftBlockPage() {
    // v1.3.20: SA's IP-level rate-limit error page — machine-retriable, NOT a
    // user-solvable challenge. Distinct error so the download loop auto-
    // retries with backoff instead of pausing for the challenge hand-off.
    const text = ((document.body && (document.body.innerText || document.body.textContent)) || '').toLowerCase();
    if (text.length >= 5000) return false;
    return text.includes('enable javascript and cookies')
        || text.includes('is this happening to you frequently')
        || text.includes('kb-tickets')
        || text.includes('ooops... something went wrong while loading this page');
  }

  if (isBotBlockPage()) {
    return { ok: false, error: 'BOT_BLOCK' };
  }
  if (isSoftBlockPage()) {
    return { ok: false, error: 'SOFT_BLOCK' };
  }

  if (typeof Readability !== 'function') {
    return { ok: false, error: 'no-readability' };
  }
  if (typeof TurndownService !== 'function') {
    return { ok: false, error: 'no-turndown' };
  }

  // Readability mutates the passed document — clone to preserve the live one.
  const docClone = document.cloneNode(true);
  const reader = new Readability(docClone);
  const article = reader.parse();
  if (!article || !article.content) {
    return { ok: false, error: 'parse-fail' };
  }

  // Second-line bot-block check — Readability sometimes parses the block page
  // "successfully" and we'd otherwise persist junk.
  if (isBotBlockPage()) {
    return { ok: false, error: 'BOT_BLOCK' };
  }
  if (isSoftBlockPage()) {
    return { ok: false, error: 'SOFT_BLOCK' };
  }

  const turndown = new TurndownService({ headingStyle: 'atx', codeBlockStyle: 'fenced', bulletListMarker: '-' });
  turndown.addRule('removePaywall', {
    filter: (node) => node.nodeType === 1 && (
      (typeof node.className === 'string' &&
        (node.className.includes('paywall') || node.className.includes('subscription') || node.className.includes('upsell')))
    ),
    replacement: () => '',
  });
  // v1.3.21: drop SA's "Recommended For You" read-next footer — cut from the
  // dedicated heading marker to end-of-content (mirrors
  // saArticle.stripSaFooterFurnitureHtml; heading-anchored so mid-body prose
  // mentioning the phrase is never touched).
  const footerMatch = /<h[1-6][^>]*>(?:\s|<[^>]+>)*(?:recommended for you|read next)(?:\s|:|<[^>]+>)*<\/h[1-6]>/i.exec(article.content);
  const contentForMarkdown = footerMatch ? article.content.slice(0, footerMatch.index) : article.content;
  const markdown = turndown.turndown(contentForMarkdown);

  return {
    ok: true,
    title: article.title || document.title || '',
    byline: article.byline || '',
    url: window.location.href,
    domain: window.location.hostname,
    body: markdown,
    bodyLength: markdown.length,
    contentHtml: article.content,
    sessionHint: sessionHint(),
  };
})();
