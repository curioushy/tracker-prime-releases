// Primus SA slides URL extraction — runs in the SA article tab.
//
// Faithful port of Alpha-Transcript-Downloader/slides_content.js. Runs 4
// strategies in sequence and returns the first URL found:
//   1. Raw fetch of the article URL (PDF URL is sometimes embedded in
//      __NEXT_DATA__ JSON in the SSR HTML, OR an `sa_presentations/X/Y/` path
//      fragment we can rebuild into the canonical CDN URL).
//   2. Article API at /api/v3/articles/{id} (and 3 variants) — same scan.
//   3. DOM scan with visibility simulation + retry — SA's viewer lazy-renders
//      only when the tab is "visible", so dispatch a synthetic visibility event
//      and retry every 0.5–3 s for ~10 s while React fills the DOM.
//   4. React fiber walk — the "View as PDF" button is a React component with
//      the URL only in its props, not in any DOM attribute. Strategy 4 runs in
//      MAIN world (separate executeScript call from Primus) and walks the fiber
//      tree; it's the last resort.
//
// Strategies 1–3 live HERE (ISOLATED world). Strategy 4 lives in
// slides-fiber.js and is injected separately by Primus.
//
// Returns { ok: true, slidesUrl, diagnostics }
//      or { ok: false, error, diagnostics }
// Returns `error: 'BOT_BLOCK'` when SA shows a verification page (same heuristic
// as extract.js).

(async () => {
  function isBotBlockPage() {
    const text = (document.body && (document.body.innerText || document.body.textContent) || '').toLowerCase();
    const hasRefId  = /reference id:\s*[a-f0-9-]+/i.test(text);
    const hasBlocky = text.includes('disable your ad-blocker')
                  || text.includes('javascript and cookies')
                  || text.includes('please enable javascript');
    if (hasRefId && hasBlocky) return true;
    if (hasRefId && text.length < 800) return true;
    const t = (document.title || '').toLowerCase();
    if (t.includes('access denied') || t.includes('attention required') || t === 'just a moment...') return true;
    // v1.3.16 (S2): DataDome / Geetest vocabulary, short-pages only (same as
    // extract.js — see its comment).
    if (text.length < 5000 && (
      text.includes('captcha')
      || text.includes('verify you are human')
      || text.includes('press & hold')
      || text.includes('press and hold')
      || text.includes('geetest')
    )) return true;
    if (text.length < 5000) {
      const frames = document.querySelectorAll('iframe[src]');
      for (let i = 0; i < frames.length; i++) {
        const src = (frames[i].getAttribute('src') || '').toLowerCase();
        if (src.includes('geetest') || src.includes('captcha')) return true;
      }
    }
    return false;
  }

  if (isBotBlockPage()) return { ok: false, error: 'BOT_BLOCK', diagnostics: [] };

  function isSoftBlockPage() {
    // v1.3.20: SA's IP-level rate-limit error page (same vocabulary as
    // extract.js) — machine-retriable; the download loop auto-retries.
    const text = ((document.body && (document.body.innerText || document.body.textContent)) || '').toLowerCase();
    if (text.length >= 5000) return false;
    return text.includes('enable javascript and cookies')
        || text.includes('is this happening to you frequently')
        || text.includes('kb-tickets')
        || text.includes('ooops... something went wrong while loading this page');
  }
  if (isSoftBlockPage()) return { ok: false, error: 'SOFT_BLOCK', diagnostics: [] };

  const diagnostics = [];

  function extractPdfUrls(text) {
    const matches = text.match(/https?:\/\/[^\s"'<>\\]+\.(pdf|pptx?)[^\s"'<>\\]*/gi);
    return matches || [];
  }

  function collectUrlsFromObject(obj, found = []) {
    if (!obj || typeof obj !== 'object') return found;
    for (const val of Object.values(obj)) {
      if (typeof val === 'string') {
        if (/https?:\/\/.+\.(pdf|pptx?)/i.test(val)) found.push(val);
      } else if (typeof val === 'object') {
        collectUrlsFromObject(val, found);
      }
    }
    return found;
  }

  // ── Strategy 1: Raw HTML fetch ──────────────────────────────────────────
  let slidesUrl = null;
  try {
    const resp = await fetch(location.href, { credentials: 'include' });
    const html = resp.ok ? await resp.text() : '';
    const urls = extractPdfUrls(html);
    const saRefs = (html.match(/sa_presentations[^\s"'<>]{0,80}/g) || []).slice(0, 2);
    diagnostics.push(`raw: status=${resp.status} len=${html.length} pdf=${urls.length} saPres=${saRefs.length}${saRefs[0] ? ':' + saRefs[0] : ''}`);
    if (urls.length) slidesUrl = urls[0];
    else if (saRefs.length) {
      const m = saRefs[0].match(/sa_presentations\/(\d+)\/(\d+)/);
      if (m) slidesUrl = `https://static.seekingalpha.com/uploads/sa_presentations/${m[1]}/${m[2]}/original.pdf`;
    }
  } catch (e) {
    diagnostics.push(`raw: error=${e.message}`);
  }

  // ── Strategy 2: Article API variants ────────────────────────────────────
  if (!slidesUrl) {
    const m = location.pathname.match(/\/article\/(\d+)/);
    if (m) {
      const aid = m[1];
      const endpoints = [
        `/api/v3/articles/${aid}`,
        `/api/v3/articles/${aid}?include=primaryTickers,fileEmbeds,embeds,presentations`,
        `/api/v3/articles/${aid}/embeds`,
        `/api/v3/articles/${aid}/files`,
      ];
      for (const ep of endpoints) {
        try {
          const resp = await fetch(ep, { credentials: 'include' });
          const text = resp.ok ? await resp.text() : '';
          const urls = extractPdfUrls(text);
          const saRefs = (text.match(/sa_presentations[^\s"'<>\\]{0,80}/g) || []);
          diagnostics.push(`api[${ep.slice(15)}]: status=${resp.status} len=${text.length} pdf=${urls.length} sa=${saRefs.length}`);
          if (urls.length) { slidesUrl = urls[0]; break; }
          if (saRefs.length) {
            const m2 = saRefs[0].match(/sa_presentations\/(\d+)\/(\d+)/);
            if (m2) { slidesUrl = `https://static.seekingalpha.com/uploads/sa_presentations/${m2[1]}/${m2[2]}/original.pdf`; break; }
          }
        } catch (e) {
          diagnostics.push(`api[${ep.slice(15)}]: error=${e.message}`);
        }
      }
    } else {
      diagnostics.push('api: no article id in URL');
    }
  }

  // ── Strategy 3: DOM scan with visibility simulation + retry ─────────────
  if (!slidesUrl) {
    try {
      Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
      Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });
      document.dispatchEvent(new Event('visibilitychange'));
      window.dispatchEvent(new Event('focus'));
    } catch { /* ignore */ }

    function findInDom() {
      const candidates = [];
      for (const el of document.querySelectorAll('iframe[src], iframe[data-src]')) {
        const src = el.getAttribute('src') || el.getAttribute('data-src') || '';
        if (/\.(pdf|pptx?)\b/i.test(src)) { candidates.push(src); continue; }
        const gm = src.match(/[?&]url=([^&]+)/);
        if (gm) {
          const inner = decodeURIComponent(gm[1]);
          if (/\.(pdf|pptx?)\b/i.test(inner)) candidates.push(inner);
        }
      }
      for (const el of document.querySelectorAll('embed[src], object[data]')) {
        const src = el.getAttribute('src') || el.getAttribute('data') || '';
        if (/\.(pdf|pptx?)\b/i.test(src)) candidates.push(src);
      }
      for (const a of document.querySelectorAll('a[href]')) {
        const href = a.href || '';
        if (/\.(pdf|pptx?)\b/i.test(href)) candidates.push(href);
      }
      for (const a of document.querySelectorAll('a[href]')) {
        const text = (a.textContent || a.getAttribute('aria-label') || '').trim();
        if (/view\s+as\s+pdf|download\s+pdf|download\s+slides|view\s+pdf/i.test(text)) candidates.push(a.href);
      }
      for (const el of document.querySelectorAll('[data-href],[data-url],[data-src]')) {
        const url = el.getAttribute('data-href') || el.getAttribute('data-url') || el.getAttribute('data-src') || '';
        if (/\.(pdf|pptx?)\b/i.test(url)) candidates.push(url);
      }
      for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
        try {
          const obj = JSON.parse(s.textContent);
          const url = obj?.contentUrl || obj?.url || '';
          if (/\.(pdf|pptx?)\b/i.test(url)) candidates.push(url);
        } catch { /* ignore */ }
      }
      const nextDataEl = document.getElementById('__NEXT_DATA__');
      if (nextDataEl) {
        try { candidates.push(...collectUrlsFromObject(JSON.parse(nextDataEl.textContent))); } catch { /* ignore */ }
      }
      candidates.push(...extractPdfUrls(document.documentElement.innerHTML));
      for (const c of candidates) {
        try { return new URL(c, location.href).href; } catch { /* skip */ }
      }
      return null;
    }

    for (const delay of [0, 500, 1000, 2000, 3000]) {
      if (delay > 0) await new Promise((r) => setTimeout(r, delay));
      const u = findInDom();
      if (u && /\.(pdf|pptx?)/i.test(u)) { slidesUrl = u; break; }
    }
    diagnostics.push(`dom: htmlLen=${document.documentElement.innerHTML.length} found=${slidesUrl || 'none'}`);
  }

  return slidesUrl
    ? { ok: true, slidesUrl, diagnostics }
    : { ok: false, error: 'no-slides-url', diagnostics };
})();
